from django.shortcuts import render
from django.db.models import Q, Count, Sum
from CartSystem.models import AddToCart, WishList
from products.models import Product
from products.serializers import ProductSerializer
from orders.models import OrderDetail, OrderProductDetail
from .serializers import PopularProductSerializer, FreshArrivalsProductSerializers
from common.models import User
from vendor.models import Vendor
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
# Create your views here.

class PopularProductInWishListAPIView(APIView):

    def get(self, request):
        wishlistProduct = WishList.objects.values('product__name', 'product__short_description').annotate(
            total=Count('product')).order_by('product')[:10]
        return Response(
            {
                "status": "Success",
                "wishlistData": wishlistProduct,
            },
            status=status.HTTP_200_OK
        )

class PopularProductInCartAPIView(APIView):

    def get(self, request):
        cartProduct = AddToCart.objects.values('product__name', 'product__short_description').annotate(
            total=Count('product')).order_by('product')[:10]
        return Response(
            {
                "status": "Success",
                "cartData": cartProduct,
            },
            status=status.HTTP_200_OK
        )
class PopularOrderedProductAPIView(APIView):

    def get(self, request):
        try:
            orderedProduct = OrderProductDetail.objects.values('product').annotate(
                total=Count('product')).order_by('product')[:10]

            allPopularProduct = []
            for pProduct in orderedProduct:
                onePopularProduct = Product.objects.filter(id=pProduct["product"])
                #print(onePopularProduct)
                allPopularProduct.append(ProductSerializer(onePopularProduct, many=True).data)

            return Response(
                {
                    "status": "Success",
                    "data": allPopularProduct,
                },
                status=status.HTTP_200_OK,
            )
        except OrderProductDetail.DoesNotExist:
            return Response({"status": "warning","message": "Opps! Popular Product not found!!!","data": [],
                }, status=204,
            )


class FreshArrivalProductAPIView(APIView):

    def get(self, request):
        try:
            newArrivalProduct = Product.objects.order_by('-created_at')[:20]
            newArrivalProductSerializerData = FreshArrivalsProductSerializers(newArrivalProduct, many=True).data
            print(newArrivalProduct)
            return Response(
                {
                    "status": "Success",
                    "data": newArrivalProductSerializerData,
                },
                status=status.HTTP_200_OK,
            )
        except OrderProductDetail.DoesNotExist:
            return Response({"status": "warning", "message": "Opps! Fresh Arrival Product not found!!!","data": [],
                },status=204,
            )


# class FrequentlyOrderedProductAPIView(APIView):
#     permission_classes = [IsAuthenticated]
#
#     def get(self, request):
#         user = self.request.user.id
#         try:
#             orderedProduct = OrderProductDetail.objects.values('product', user).annotate(
#                 total=Count('product')).order_by('product')[:10]
#
#             allPopularProduct = []
#             for pProduct in orderedProduct:
#                 onePopularProduct = Product.objects.filter(id=pProduct["product"])
#                 #print(onePopularProduct)
#                 allPopularProduct.append(ProductSerializer(onePopularProduct, many=True).data)
#
#             return Response(
#                 {
#                     "status": "Success",
#                     "data": allPopularProduct,
#                 },
#                 status=status.HTTP_200_OK,
#             )
#         except OrderProductDetail.DoesNotExist:
#             return Response({"status": "warning","message": "Opps! Popular Product not found!!!","data": [],
#                 }, status=204,
#             )