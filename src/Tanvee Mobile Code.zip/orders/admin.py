from django.contrib import admin
from orders.models import OrderDetail, ContactAddress, OrderProductDetail, VendorOrderDetails

# admin.site.register(OrderNumber)

# Register ContactAddress Model
class ContactAddressAdmin(admin.ModelAdmin):
    list_display = ['id', 'name']
admin.site.register(ContactAddress, ContactAddressAdmin)


# Register OrderDetail
class OrderDetailAdmin(admin.ModelAdmin):
    list_display = ["id",
                    "order_number",
                    "address",
                    "price",
                    "shipping_charge",
                    "tax",
                    "offer_discount",
                    "grand_total",
                    "payment_method",
                    "payment_status",
                    "delivery_exe",
                    "order_status"]
    list_display_links = ["id", "order_number"]
    list_filter = ["id", "order_number", "grand_total", "payment_method", "payment_status", "order_status"]
    search_fields = ["id", "order_number", "grand_total", "payment_method", "payment_status", "order_status"]



admin.site.register(OrderDetail, OrderDetailAdmin)


# Register OrderProductDetail Model
class OrderProductDetailAdmin(admin.ModelAdmin):

    list_display = ["id",
                    "order",
                    "product",
                    "price",
                    "quantity",
                    "total_price",
                    ]
    list_display_links = ["id","order"]
    list_filter = ["id", "order", "price", "total_price"]
    search_fields = ["id", "order", "price", "total_price"]

admin.site.register(OrderProductDetail, OrderProductDetailAdmin)


# Register VendorOrderDetails Model
# Register OrderProductDetail Model
class VendorOrderDetailsAdmin(admin.ModelAdmin):

    list_display = ["id",
                    "order",
                    "vendor",
                    "total_items",
                    "total_quantity",
                    "total_price",
                    "total_tax",
                    "grand_total",
                    "order_status",
                    ]
    list_display_links = ["id","order", "vendor"]
    list_filter = ["id", "order", "vendor", "total_price"]
    search_fields = ["id", "order", "vendor"]
admin.site.register(VendorOrderDetails, VendorOrderDetailsAdmin)