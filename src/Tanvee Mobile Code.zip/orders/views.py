from operator import le
from django.shortcuts import render
from rest_framework.permissions import IsAuthenticated
from .serializers import (
    OrderDetailSerializer, OrderProductDetailSerializer, 
    ContactAddressSerializer, VendorOrderDetailsSerializer, OrderProductDetailSerializerD2)

from .models import OrderDetail, OrderProductDetail, ContactAddress, VendorOrderDetails
from CartSystem.models import AddToCart
from CartSystem.serializers import AddToCartSerializer, CartItemSerializer
from Offers.serializers import OfferSerializer, OfferSerializerInPutValidatation
from Offers.models import Offer
from Offers import helper
from rest_framework.views import APIView
from vendor.models import Vendor
from rest_framework.generics import DestroyAPIView, ListAPIView
from rest_framework.response import Response
from rest_framework.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404
from rest_framework import status
import decimal
from products.models import Product
from CartSystem.common.cart_system import get_cart_amt_detail, deleteCartAllProducts
import razorpay
from django.conf import settings


# client = razorpay.Client(auth=("YOUR_ID", "YOUR_SECRET"))
# client.order.payment(orderId)

# authorize razorpay client with API Keys.
razorpay_client = razorpay.Client(auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET_KEY))

class orderHelperClass():
    def createOrder(self, request):
        user = request.user
        payment_method = request.data.get("payment_method", False)
        if payment_method != "COD" and payment_method != "Razorpay":
            return {
                "status": "warning",
                "status_code": 400,
                "message": "Invalid payment method"
            }

        cartAmtDetails = get_cart_amt_detail(request)

        if cartAmtDetails["cartNoOfProducts"] < 1:
            return {
                "status": "warning",
                "status_code": 406,
                "message": "Opps!! You don't have any products in cart to place order!"
            }

        # Discount 0ffer
        totalDiscount = 0
        offerCode = request.data.get("offer_code", False)
        discountResponse, discountStatus = helper.getOfferDiscountAmnt(request)
        if discountStatus == 200:
            totalDiscount = discountResponse["discount"]

        totalShippingCharge = 0.00 if cartAmtDetails["cartAmt"] >= 500 else 10

        grandTotal = (cartAmtDetails["cartAmt"] + cartAmtDetails["cartTaxAmt"] + decimal.Decimal(
            totalShippingCharge)) - decimal.Decimal(totalDiscount)
        grandSubTotal = grandTotal + decimal.Decimal(totalDiscount)

        # Shipping(Customer-Address) Address Data
        user_address = ContactAddress.objects.filter(user=user, is_default=True).first()
        user_address_serializer_data = ContactAddressSerializer(user_address).data

        # Cart Data
        cart = AddToCart.objects.filter(user=user)
        cart_serializer_data = CartItemSerializer(cart, many=True).data

        order_status = "Order Placed"

        # Creating Order
        order = OrderDetail.objects.create(user=user,
                                           address=user_address,
                                           offer_code=offerCode,
                                           price=cartAmtDetails["cartAmt"],
                                           shipping_charge=totalShippingCharge,
                                           tax=cartAmtDetails["cartTaxAmt"],
                                           offer_discount=totalDiscount,
                                           grand_total=grandTotal,
                                           payment_method=payment_method,
                                           payment_status="Pending",
                                           order_status=order_status)
        order.save()
        orderCartItemSavedCounter = 0

        for oneCartItem in cart_serializer_data:
            orderItemsCreate = OrderProductDetail.objects.create(order=order,
                                                                 product=Product.objects.get(
                                                                     id=oneCartItem["product"]["id"]),
                                                                 quantity=oneCartItem["quantity"])
            orderItemsCreate.save()
            orderCartItemSavedCounter += 1

            vendorObj = Vendor.objects.get(id=oneCartItem["product"]["vendor"])

            cartItemPrice = float(oneCartItem["product"]["price"])
            cartItemQuantity = int(oneCartItem["quantity"])
            cartItemTaxPercentage = float(oneCartItem["product"]["tax"])
            cartItemTotalTaxAmt = float(((cartItemPrice * cartItemQuantity) * cartItemTaxPercentage) / 100)
            cartItemTotalPrice = float(cartItemPrice * cartItemQuantity)
            cartItemGrandTotalPrice = float(cartItemTotalPrice + cartItemTotalTaxAmt)

            try:
                vendorOrderObj = VendorOrderDetails.objects.get(order=order, vendor=vendorObj)
                vendorOrderData = VendorOrderDetailsSerializer(vendorOrderObj, many=False).data

                vendorOrderUpdateData = {
                    "total_items": 1 + vendorOrderData["total_items"],
                    "total_quantity": cartItemQuantity + vendorOrderData["total_quantity"],
                    "total_price": cartItemTotalPrice + float(vendorOrderData["total_price"]),
                    "total_tax": cartItemTotalTaxAmt + float(vendorOrderData["total_tax"]),
                    "grand_total": cartItemGrandTotalPrice + float(vendorOrderData["grand_total"])
                }
                VendorOrderDetailsSerializerObj = VendorOrderDetailsSerializer(vendorOrderObj, vendorOrderUpdateData,
                                                                               partial=True)
                if VendorOrderDetailsSerializerObj.is_valid():
                    VendorOrderDetailsSerializerObj.save()

            except VendorOrderDetails.DoesNotExist:
                VendorOrderDetailsObj = VendorOrderDetails.objects.create(vendor=vendorObj,
                                                                          order=order,
                                                                          total_items=1,
                                                                          total_quantity=cartItemQuantity,
                                                                          total_price=cartItemTotalPrice,
                                                                          total_tax=cartItemTotalTaxAmt,
                                                                          grand_total=cartItemGrandTotalPrice)
                VendorOrderDetailsObj.save()

        if len(cart_serializer_data) == orderCartItemSavedCounter:
            isDeletedCartAllItems = deleteCartAllProducts(request)
            return {
                "status": "success",
                "status_code": 200,
                "message": "Thanks!! Your order is successfully placed!",
                "data": {
                    "order_id": order.order_number,
                    "total_amount": cartAmtDetails["cartAmt"],
                    "total_tax": cartAmtDetails["cartTaxAmt"],
                    "total_shipping": totalShippingCharge,
                    "sub_total": grandSubTotal,
                    "total_discount": totalDiscount,
                    "grand_total": grandTotal
                }
            }
        else:
            return {
                "status": "warning",
                "status_code": 400,
                "message": "Opps!! Something went wrong, try to re-order!"
            }


# OrderDetail API
class OrderDetailsAPIView(APIView):
    permission_classes = [IsAuthenticated, ]
    def get(self,request):
        user = request.user
        orderList = OrderDetail.objects.filter(user=user)
        orderListSerializeData = OrderDetailSerializer(orderList, many=True).data

        #print(orderListSerializeData)
        if len(orderListSerializeData)>0:
            responseData = {
                "status": "success",
                "message": "Order list found",
                "data": orderListSerializeData
            }
            return Response(responseData, status=status.HTTP_200_OK)
        else:
            responseData = {
                "status": "warning",
                "message": "You don't have any order!",
                "data":[]
            }
            return Response(responseData, status=status.HTTP_404_NOT_FOUND)

    def post(self, request, *args, **kwargs):
        user = request.user
        payment_method = self.request.data.get("payment_method", False)

        if payment_method != 'COD':
            return Response({"status":"warning","message":"Please select COD for place order by this api"},status=406)

        orderHelperClassObj = orderHelperClass()
        createOrderHelperResponse = orderHelperClassObj.createOrder(request)

        if createOrderHelperResponse["status"] == "success":
            return Response(createOrderHelperResponse, status=201)
        else:
            return Response(createOrderHelperResponse, status=createOrderHelperResponse["status_code"])


class CreateRazorpayOrder(APIView):
    permission_classes = [IsAuthenticated]
    def post(self,request):
        user = request.user
        payment_method = self.request.data.get("payment_method", False)

        if payment_method != 'Razorpay':
            return Response({"status":"warning","message":"Please select Razorpay to place order by this api"}, status=406)

        orderHelperClassObj = orderHelperClass()
        createOrderHelperResponse = orderHelperClassObj.createOrder(request)
        if createOrderHelperResponse["status"] == "success":
            orderDetails = createOrderHelperResponse["data"]
            currency = "INR"
            amount = int(float(orderDetails["grand_total"])*100)
            order_number = orderDetails["order_id"]

            # Create a Razorpay Order
            razorpay_order = razorpay_client.order.create(dict(amount=amount,
                                                               currency=currency,
                                                               payment_capture=1,
                                                            receipt=order_number))

            responseData = {
                "status": "success",
                "message": "Waiting for razorpay payment",
                "data": razorpay_order
            }
            return Response(responseData, status=status.HTTP_200_OK)
        else:
            responseData = {
                "status": "warning",
                "message": "Opps!! Something went wrong, try again!!!"
            }
            return Response(createOrderHelperResponse, status=createOrderHelperResponse["status_code"])


# [POST] api/customer/order-place-razorpay-verify/
# [REQUEST]:
# {
#     "order_number" : "ORD50807130303",
#     "razorpay_order_id":"",
#     "razorpay_payment_id": "",
#     "razorpay_signature": ""
# }
# [RESPONSE]:
# {
#     "order_number" : "ORD50807130303",
#     "razorpay_order_id":"",
#     "razorpay_payment_id": "",
#     "razorpay_signature": ""
# }
class RazorPayVerifyPaymentAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        userObj = self.request.user
        # print(request.data)

        order_number = request.data.get("order_number", False)      # order_number is nothing but a receipt no which is provided by create order api response
        razorpay_payment_id = request.data.get('razorpay_payment_id', '')
        razorpay_order_id = request.data.get('razorpay_order_id', '')
        razorpay_signature = request.data.get('razorpay_signature', '')

        try:
            orderObj = OrderDetail.objects.get(order_number=order_number, user=userObj)
            orderDetailsData = OrderDetailSerializer(orderObj, many=False).data
            print(orderDetailsData)


            currency = 'INR'
            amount = int(float(orderDetailsData["grand_total"]) * 100)  # Rs.
            print(amount)
            print(type(amount))
            try:

                params_dict = {
                    'razorpay_order_id': razorpay_order_id,
                    'razorpay_payment_id': razorpay_payment_id,
                    'razorpay_signature': razorpay_signature
                }

                print(params_dict)
                # verify the payment signature.
                result = razorpay_client.utility.verify_payment_signature(params_dict)
                print(result)
                if result is None:
                    try:
                        # capture the payment
                        #razorpay_client.payment.capture(razorpay_payment_id, amount)
                        # render success page on successful caputre of payment
                        return Response({"status": "success", "message": "Payment Success!"},
                                        status=status.HTTP_201_CREATED)
                    except:
                        # if there is an error while capturing payment.
                        return Response({"status": "warning", "message": "Payment Failed!"},
                                        status=status.HTTP_406_NOT_ACCEPTABLE)

                else:
                    # if signature verification fails.
                    return Response({"status": "warning", "message": "Invalid Payment!"},
                                    status=status.HTTP_406_NOT_ACCEPTABLE)
            except:
                # if we don't find the required parameters in POST data
                return Response({"status": "warning", "message": "Invalid Inputes!"},
                                status=status.HTTP_400_BAD_REQUEST)


        except OrderDetail.DoesNotExist:
            return Response({
                "status" : "warning",
                "message" : "Order id not valid"
            }, status = status.HTTP_400_BAD_REQUEST)





class OrderDetailUpdateApiView(APIView):

    permission_classes = [IsAuthenticated, ]

    def patch(self, request, pk):
        user_id=self.request.user.id
        try:
            user = request.user
            order = OrderDetail.objects.get(pk=pk)
            order_status = request.data['order_status']
            # order_status =order_status
            serializer = OrderDetailSerializer(
                order, order_status=order_status, context={"request": request}
            )
            serializer.is_valid(raise_exception=True)
            serializer.save()
            responseData = {
                "status": "success",
                "orderNumber": order.order_number,
                "order_status": order_status,
                "msg": "Order Cancelled.",
                "data": serializer.data
            }

            return Response(responseData, status=status.HTTP_200_OK)

        except (OrderDetail.DoesNotExist, Exception) as e:
            print(e)
            return Response({"data": {"message": "Somthing Went to Wrong!!"}}, status=status.HTTP_404_NOT_FOUND)

    # def put(self, request, pk):
    #     user = request.user
    #     user_address = get_object_or_404(ContactAddress, pk=pk)
    #     if user_address.user != user:
    #         raise PermissionDenied("This Action You can't Perform!!")
    #     serializer = ContactAddressSerializer(
    #     user_address, data=request.data, context={"request": request}
    #     )
    #     serializer.is_valid(raise_exception=True)
    #     serializer.save()
    #     responseData = {
    #         "status": "success",
    #         "message": "Your Address is Successfully Updated!!",
    #         "data": serializer.data
    #         }
    #
    #     return Response(responseData, status = status.HTTP_201_CREATED)


# OrderDetail API

# class OrderProductsHistoryAPIView(APIView):
#     permission_classes = [IsAuthenticated, ]
#
#     def get(self,request):
#         user = request.user
#         order_number = request.data.get('order_number')
#         order = OrderDetail.objects.filter(order_number=order_number)
#         orderedproductList = OrderProductDetail.objects.filter(order=order)
#         orderedProductListSerializeData = OrderProductDetailSerializer(orderedproductList, many=True).data
#
#         #print(orderListSerializeData)
#         if len(orderedProductListSerializeData)>0:
#             responseData = {
#                 "status": "success",
#                 "message": "Ordered Product list found!!!",
#                 "data": orderedProductListSerializeData
#             }
#             return Response(responseData, status=status.HTTP_200_OK)
#         else:
#             responseData = {
#                 "status": "warning",
#                 "message": "No order Placed!"
#             }
#             return Response(responseData, status=status.HTTP_404_NOT_FOUND)
class OrderProductsHistoryAPIView(ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = OrderProductDetailSerializer
    queryset = OrderProductDetail.objects.all().order_by('-id')


class UserOrderProductHistoryAPIView(APIView):

    permission_classes = [IsAuthenticated]
    def get(self, request):
        orderObj = OrderDetail.objects.filter(user_id=request.user.id)
        orderData = OrderDetailSerializer(orderObj, many=True).data
        print(orderObj)
        
        orderList = []

        for i in range(len(orderData)):
            oneOrder = orderData[i]
            orderProductObj = OrderProductDetail.objects.filter(order_id=oneOrder["id"])
            orderProductData = OrderProductDetailSerializerD2(orderProductObj, many=True).data
            for op in range(len(orderProductData)):
                # print(orderProductData)
                orderProductData[op]["product"].pop("vendor")
                # print(orderProductData)
            #orderProductData
            oneOrderFullDetails = {
                "order_details" : oneOrder,
                "order_products" : orderProductData
            }
            orderList.append(oneOrderFullDetails)


        # try:
        #     orderProductObj = OrderProductDetail.objects.filter(order=orderObj, order__order_status="Order Placed")
        #     orderProductData = OrderProductDetailSerializer(orderProductObj, many=True).data

        #     response = {
        #         "status": "Success",
        #         "orderData": orderData,
        #         "productData": orderProductData
        #     }

        #     return Response(response, status=200)
        # except OrderProductDetail.DoesNotExist:
        #     return Response({"status":"warning", "message":"order not found"}, status=204)
        return Response({"data":orderList}, status=204)




class CustomerAddressAPIView(APIView):

    permission_classes = [IsAuthenticated, ]

    def get(self, request):
        user = request.user
        user_address = ContactAddress.objects.filter(user=user)
        user_address_serializer_data = ContactAddressSerializer(user_address, many=True).data

        if len(user_address_serializer_data)>0:
            responseData = {
                "status": "success",
                "message": "Address list found",
                "data": user_address_serializer_data
            }
            return Response(responseData, status=status.HTTP_200_OK)
        else:
            responseData = {
                "status": "warning",
                "message": "You don't have any saved addresses!",
                "data":[]
            }
            return Response(responseData, status=status.HTTP_404_NOT_FOUND)

    def post (self, request, *args, **kwargs):

        user = request.user
        customer_name = request.data.get('name', False)
        contactNumber = request.data.get('contact_number', False)
        post_code = request.data.get('postcode', False)
        addressLine = request.data.get('address_line', False)
        locality = request.data.get('locality', False)
        city = request.data.get('city', False)
        state = request.data.get('state', False)
        # save_address_as = request.data.get('save_address_as', False)


        user_contactAddress = ContactAddress.objects.create(user=user,
                                           name=customer_name,
                                           contact_number=contactNumber,
                                           postcode=post_code,
                                           address_line=addressLine,
                                           locality=locality,
                                           city=city,
                                           state=state
                                           )
        user_contactAddress.save()
        responseData={
                        "status" : "success",
                        "message" : "Your Address is Successfully Saved!!",
                        "data": {
                            "name": customer_name,
                            "contact_number": contactNumber,
                            "postcode": post_code,
                            "address_line": addressLine,
                            "locality": locality,
                            "city": city,
                            "state": state
                }
            }
        return Response(responseData, status=status.HTTP_200_OK)

class UpdateContactAddressApiView(APIView):

    permission_classes = [IsAuthenticated, ]

    def put(self, request, pk):
        user = self.request.user
        user_address = get_object_or_404(ContactAddress, pk=pk)
        if user_address.user != user:
            raise PermissionDenied("This Action You can't Perform!!")
        serializer = ContactAddressSerializer(
        user_address, data=self.request.data, context={"request": request}
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        responseData = {
            "status": "success",
            "message": "Your Address is Successfully Updated!!",
            "data": serializer.data
            }
        return Response(responseData, status = status.HTTP_201_CREATED)

class ContactAddressDeleteApiView(APIView):

    permission_classes = [IsAuthenticated, ]

    def delete(self, request, pk, format=None):
        address = ContactAddress.objects.get(pk=pk)
        print(address)
        address.delete()
        responseData = {
            "status": "success",
            "message": "Your Address is Successfully deleted!!"
        }
        return Response({"data": responseData}, status=status.HTTP_200_OK)

class DestroyContactAddressAPIView(DestroyAPIView):

    permission_classes = [IsAuthenticated,]
    serializer_class = ContactAddressSerializer
    queryset = ContactAddress.objects.all()

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.is_deleted = True
        instance.save()
        responseData = {
            "status": "success",
            "message": "Your Address is Successfully deleted!!"
        }
        return Response({"detail": responseData}, status=status.HTTP_200_OK)

# This Api is Used for GET, Add
class UserAddressAPIview(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        userObj = request.user
        try:
            userAddObj = ContactAddress.objects.get(user=userObj)
            jsonData = ContactAddressSerializer(userAddObj, many=False)
            userAddressDetails = jsonData.data
            return Response(
                {"status": "success", "message": "Address fetched successfully", "data": userAddressDetails},
                status=200)
        except ContactAddress.DoesNotExist:
            return Response({"status": "warning", "message": "You don't have an address", "data":[]}, status=404)

    def post(self, request):
        userObj = request.user
        regData = request.data
        # regData["user"] = userObj.id

        try:
            userAddObj = ContactAddress.objects.get(user=userObj.id)
            # jsonData = VendorProfileAddressSerializer(vendorAddObj,many=False)
            userAddressSerializer = ContactAddressSerializer(userAddObj, data=regData, partial=True)
            if userAddressSerializer.is_valid():
                userAddressSerializer.save()
                return Response({"status": "success", "message": "Address updated successfully"}, status=200)
            else:
                return Response(
                    {"status": "warning", "message": "Invalid inputes", "errors": userAddressSerializer.errors},
                    status=400)
        except ContactAddress.DoesNotExist:
            # userAddressSerializer = ContactAddressSerializer(data=regData)
            # if userAddressSerializer.is_valid():
            #     userAddressSerializer.save()
            #     return Response({"status": "success", "message": "Address added successfully"}, status=201)
            # else:
            #     return Response(
            #         {"status": "warning", "message": "Invalid inputes", "errors": userAddressSerializer.errors},
            #         status=400)
            return Response(
                    {"status": "warning", "message": "Invalid inputes", "errors": userAddressSerializer.errors},
                    status=400)