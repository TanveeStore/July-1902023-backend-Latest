from django.shortcuts import render
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.views import APIView
from common.models import Profile
from rest_framework.generics import UpdateAPIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from common.models import User
from common.serializer.user_serializers import (
    AddressSerializer,
    UpdateProfileSerializer,
    UserSerializer,
    UpdateAddressSerializer,
    UserCompleteSerializer,
    UserProfileBasicSerializerUpdate,
)
# Create your views here.
class UserProfileDetailAPIView(APIView):
    #permission_classes = (IsAuthenticated)

    def get_object(self, pk):
        profile = get_object_or_404(Profile, pk=pk)
        return profile

    def put(self, request, pk, format=None):
        params = request.query_params if len(
            request.data) == 0 else request.data
        profile = self.get_object(pk)
        address_obj = profile.address


        serializer = UserSerializer(
            data=params, instance=profile.user)
        address_serializer = UpdateAddressSerializer(
            data=params, instance=address_obj)
        profile_serializer = UpdateProfileSerializer(
            data=params, instance=profile)
        data = {}
        if not serializer.is_valid():
            data["contact_errors"] = serializer.errors
        if not address_serializer.is_valid():
            data["address_errors"] = (address_serializer.errors,)
        if not profile_serializer.is_valid():
            data["profile_errors"] = (profile_serializer.errors,)
        if data:
            data["error"] = True
            return Response(
                data,
                status=status.HTTP_400_BAD_REQUEST,
            )
        if serializer.is_valid():
            address_obj = address_serializer.save()
            user = serializer.save()
            user.username = user.first_name
            user.save()
            profile = profile_serializer.save()
            return Response(
                {"error": False, "message": "User Updated Successfully"},
                status=status.HTTP_200_OK,
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )


# User Profile Get And Update
class UserProfileBasicAPIview(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        userObj = User.objects.get(id=self.request.user.id)
        jsonData = UserCompleteSerializer(userObj)
        vendorProfile = jsonData.data
        return Response({"status": "success", "message": "Basic Profile fetched successfully",
                         "data": vendorProfile}, status=200)

    def post(self, request):
        userObj=User.objects.get(id=self.request.user.id)
        basicProfileSerializer = UserProfileBasicSerializerUpdate(userObj, data=request.data, partial=True)

        if basicProfileSerializer.is_valid():
            basicProfileSerializer.save()
            return Response({"status": "success","message":"Basic Profile updated successfully"},status=200)
        else:
            return Response({"status": "warning","message":"Invalid inputes","errors":basicProfileSerializer.errors},status=400)